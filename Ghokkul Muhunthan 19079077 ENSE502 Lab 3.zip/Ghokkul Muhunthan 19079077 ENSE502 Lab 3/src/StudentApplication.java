public class StudentApplication {

	public static void main(String[] args) {
		
		// From the student class using the 3rd parameter constructor. 
		Student aStudent = new Student("Justin", "Case", "01234");
		
		System.out.println(aStudent);
	}

}
