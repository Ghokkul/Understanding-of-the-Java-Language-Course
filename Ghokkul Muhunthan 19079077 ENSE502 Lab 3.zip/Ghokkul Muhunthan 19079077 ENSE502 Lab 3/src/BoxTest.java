import java.util.Random;

public class BoxTest {

	public static void main(String[] args) {

		//Creating the random class
		Random rand = new Random();

		//Creating the array
		Box[] boxes = new Box[5];
		
		// For loop to initialize randomly generated attributes into the array.
		for (int index = 0; index < boxes.length; index++) 
		{
			//Generates numbers between 1 to 10.
			int measurements = rand.nextInt(10) + 1;
			
			boxes[index] = new Box(measurements, measurements, measurements);
		}
	
		//Outputting the attributes
		for(Box box : boxes)
		{
			System.out.println(box);
		}
	}

}
