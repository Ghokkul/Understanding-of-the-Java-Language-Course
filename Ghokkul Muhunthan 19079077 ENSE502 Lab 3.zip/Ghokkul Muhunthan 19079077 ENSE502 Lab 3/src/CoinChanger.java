
public class CoinChanger {
	
	private int ten;
	private int twenty;
	private int fifty;
	private int oneDollar;
	private int twoDollar;
	
	// Getter and setter methods.
		public int getTen() 
		{
			return ten;
		}

		public void setTen(int ten)
		{
			if (ten >= 0)
			{
				this.ten = ten;			
			}
			else
			{
				this.ten = 0;
			}
		}

		public int getTwenty() 
		{
			return twenty;
		}

		public void setTwenty(int twenty) 
		{
			if (twenty >= 0)
			{
				this.twenty = twenty;	
			}
			else
			{
				this.twenty = 0;
			}
		}

		public int getFifty() 
		{
			return fifty;
		}

		public void setFifty(int fifty) 
		{
			if (fifty >= 0)
			{
				this.fifty = fifty;
			}
			else
			{
				this.fifty = 0;
			}
		}

		public int getOneDollar() 
		{
			return oneDollar;
		}

		public void setOneDollar(int oneDollar) 
		{
			if (oneDollar >= 0)
			{
				this.oneDollar = oneDollar;	
			}
			else
			{
				this.oneDollar = 0;
			}
			
		}

		public int getTwoDollar() 
		{
			return twoDollar;
		}

		public void setTwoDollar(int twoDollar) 
		{
			if (twoDollar >= 0)
			{
				this.twoDollar = twoDollar;	
			}
			else
			{
				this.twoDollar = 0;
			}
			
		}
		
		public int computeChange()
		{
			return ((this.ten * 10) + (this.twenty * 20) + (this.fifty * 50) + (this.oneDollar * 100) + (this.twoDollar * 200));
		}
		
		public int dollars()
		{
			return (computeChange() / 100);
		}
		
		public int cents()
		{
			return (computeChange() % 100);
		}
		
		public String toString()
		{
			return ("The total value of the coin collection is: $" + this.dollars() + "." + String.format("%02d", this.cents()));
		}
}
