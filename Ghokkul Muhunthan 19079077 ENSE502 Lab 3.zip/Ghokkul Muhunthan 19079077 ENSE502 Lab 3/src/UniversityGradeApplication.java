public class UniversityGradeApplication {

	public static void main(String[] args) {
		
		Grade p2 = new Grade(75);
		

		//Calling the setPercentage method from Grade class.
		p2.setPercentage(95);
		
		
		System.out.println("Percentage: " + p2.getPercentage());
	}

}
