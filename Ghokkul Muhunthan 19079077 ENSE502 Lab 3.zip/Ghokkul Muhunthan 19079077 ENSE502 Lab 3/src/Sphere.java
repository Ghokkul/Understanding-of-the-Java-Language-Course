
public class Sphere {

	private double diameter;

	// 1 parameter constructor.
	public Sphere(double diameter) 
	{
		this.setDiameter(diameter);
	}
	
	// Zero parameter constructor.
	public Sphere() 
	{
		this.setDiameter(0);
	}
	
	public double getDiameter() 
	{
		return diameter;
	}

	public void setDiameter(double diameter) 
	{
		if(diameter > 0.01)
		{
			this.diameter = diameter;			
		}
		else
		{
			this.diameter = 1.00;
		}
	}

	public double computeSurfaceArea()
	{
		return (4.0 * Math.PI * Math.pow((this.diameter / 2.0), 2.0));
	}
	
	public double computeVolume()
	{
		return ((4.0/3.0) * Math.PI * Math.pow((this.diameter/2.0), 3.0));
	}
	
		public String toString()
	{
			return ("Volume: " + String.format("%.2f", this.computeVolume()) + " units cubed\n" 
				+ "Surface Area: " + String.format("%.2f", this.computeSurfaceArea()) + " units squared\n");
	}

}
