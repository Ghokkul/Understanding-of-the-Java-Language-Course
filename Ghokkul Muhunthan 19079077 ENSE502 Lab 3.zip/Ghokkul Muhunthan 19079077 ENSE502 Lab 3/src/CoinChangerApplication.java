import java.util.Scanner;

public class CoinChangerApplication {

	public static void main(String[] args) {
		
		//New Scanner class.
		Scanner scanner = new Scanner(System.in);
		
		char userInput = '\0';
		
		do
		{
			// Outputs welcome message.
			System.out.println("Welcome to the Coin Changer Machine. Please input your coins:");
		
			CoinChanger test = new CoinChanger();
			
			//Calling the getNumberOfCoins from CoinChanger.
			test.setTen(getNumberOfCoins("10c", scanner));
			test.setTwenty(getNumberOfCoins("20c", scanner));
			test.setFifty(getNumberOfCoins("50c", scanner));
			test.setOneDollar(getNumberOfCoins("dollar", scanner));
			test.setTwoDollar(getNumberOfCoins("two dollar", scanner));
			
		
			System.out.println(test);
			
			//Asking user if they wish to continue.
			System.out.println("Would you like to continue? (Y?)");
			userInput = scanner.next().charAt(0);
		}
		while (userInput == 'Y' || userInput == 'y');
	}
	
	public static int getNumberOfCoins(String coinType, Scanner scanner)
	{
		System.out.printf("Number of %s coins:\n", coinType);
		return (scanner.nextInt());
	}
}
