
public class Grade {
	
	// a value in the range 0..100.
	private int percentage; 
	
	// 1 parameter constructor.
	public Grade(int percentage)
	{
		this.setPercentage(percentage);
	}
	
	// Getter and setter methods.
	public int getPercentage()
	{
		return this.percentage;
	}
	
	public void setPercentage(int percentage)
	{
		if((percentage >= 0) && (percentage <= 100))
		{
			this.percentage = percentage;
		}
		else
		{
			this.percentage = 0;
		}
	}
}
