import java.util.Random;


public class MultiSphere 
{

	public static void main(String[] args) {
		{
			//Random Class.
			Random rand = new Random();
					
			//Array size of 7.
			Sphere[] spheres = new Sphere[7];
			
			for(int index = 0; index < spheres.length; index++)
			{
				//Generates between 1 to 10.
				int randomDiameter = rand.nextInt(10) + 1;
				spheres[index] = new Sphere(randomDiameter);
			}
			
			// For loop to output details of the spheres created.
			for(int index2 = 0; index2 < spheres.length; index2++)
			{
				System.out.println("Sphere " + (index2 + 1) + "\'s Attributes:\n" + "----------------------");
				
				System.out.println(spheres[index2]);
			}
			}
		
	}
}


	