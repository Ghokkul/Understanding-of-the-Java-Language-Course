
public class Dog {
	
	private int age;
	private String name;
	
	// 1st parameter constructor.
	public Dog(String name, int age)
	{
		this.setName(name);
		this.setAge(age);
	}
	
	// 2nd parameter constructor.
	public Dog() 
	{
		this.name = "UNKNOWN";
		this.age = 0;
	}
	
	// Getter and setter methods.
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		// If and else statement to confirm name.
		if (name.isEmpty() || name.equals("")) 
		{
			this.name = "UNKNOWN";
		}
		else
		{
			this.name = name;			
		}
	}

	public int getAge() 
	{
		return age;
	}

	public void setAge(int age) 
	{
		// If and else statement to confirm dog's age.
		if(age >= 0 && age <= 50)
		{
			this.age = age;		
		}
		else
		{
			this.age = 0;
		}
	}
	public int computeHumanYears()
	{
		//Formula to compute human years.
		return (this.age * 7);
	}
	
	@Override
	public String toString()
	{
		return ("Dog\'s name: " + this.name + ", age: " + this.age + " years, human years: " + this.computeHumanYears() + " years");
	}

}
