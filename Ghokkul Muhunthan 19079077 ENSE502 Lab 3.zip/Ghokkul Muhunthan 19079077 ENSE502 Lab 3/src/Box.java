
public class Box {

	private double height;
	private double width;
	private double depth;
	private boolean full;
	
		//3rd parameter constructor.
		public Box(double height, double width, double depth) 
		{
			this.setHeight(height);
			this.setWidth(width);
			this.setDepth(depth);
			this.setFull(false);
		}

		// Zero parameter constructor.
		public Box()
		{
			this.setHeight(0);
			this.setWidth(0);
			this.setDepth(0);
			this.setFull(false);
		}

		public double getHeight() 
		{
			return height;
		}

		public void setHeight(double height) 
		{ 
			// If and else statement to confirm measurements.
			if (height >= 0.01)
			{
				this.height = height;
			}
			else
			{
				this.height = 1;			
			}
		}

		public double getWidth() 
		{
			return width;
		}

		public void setWidth(double width) 
		{
			// If and else statement to confirm measurements.
			if (width >= 0.01)
			{
				this.width = width;
			}
			else
			{
				this.width = 1;			
			}
		}

		public double getDepth() 
		{
			return depth;
		}

		public void setDepth(double depth) 
		{
			// If and else statement to confirm measurements.
			if (depth >= 0.01)
			{
				this.depth = depth;
			}
			else
			{
				this.depth = 1;			
			}
		}

		public boolean isFull() 
		{
			return full;
		}

		public void setFull(boolean full) 
		{
			this.full = full;
		}
		
		public String toString()
		{
			return ("Box\'s height: " + this.height + " width: " + this.width + " depth: " + this.depth + " full: " + this.full);
		}

}
