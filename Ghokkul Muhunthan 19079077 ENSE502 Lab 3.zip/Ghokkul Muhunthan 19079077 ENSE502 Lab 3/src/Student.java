
public class Student {
	
	private String firstname;
	private String lastname;
	private String studentID;
	
	
	// 3-parameter constructor.
	Student (String firstname, String lastname, String studentID)
	{
		this.firstname = firstname;
		this.lastname = lastname;
		this.studentID = studentID;		
	}
	
	// 1-parameter constructor.
	Student (String studentID)
	{
		this.firstname = "";
		this.lastname = "";
		this.studentID = studentID;
	}
	
	
	// toString method to output attributes of Student object.
	public String toString()
	{
		return ("Student\'s first name: " + this.firstname + ", last name: " + this.lastname + ", ID: " + this.studentID);
	}
}
