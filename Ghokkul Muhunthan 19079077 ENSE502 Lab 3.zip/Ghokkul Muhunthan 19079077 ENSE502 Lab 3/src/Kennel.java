import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Kennel {

	public static void main(String[] args) {
		
		//Listing dogs using dynamic array list.
		List<Dog> dogs = new ArrayList<Dog>();
			
		//New Scanner class created.
		Scanner scanner = new Scanner(System.in);
				
		// Asking user how many dogs would you like to enter data for.
		System.out.println("How many dogs would you like to enter data for?");
		int frequency = scanner.nextInt();
				
		//Collects data from the user.
		for (int index = 0; index < frequency; index++)
			{
				System.out.printf("What is the dog %d\'s name?\n", index + 1);
				String dogName = scanner.next();
					
				System.out.printf("What is the dog %d\'s age?\n", index + 1);
				int dogAge = scanner.nextInt();
								
				dogs.add(new Dog(dogName, dogAge));
			}
				
		scanner.close();
				
		
		//Outputting the stored list of attributes.
		for(Dog dog : dogs)
		{
			System.out.println(dog);
		}
	}

}
