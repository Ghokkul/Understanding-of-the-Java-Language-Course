public enum ScoreAction 
{
	TRY(5), CONVERSIONKICK(2), PENALTYKICK(3),DROPGOAL(3);
	private int pointsRewarded;
	
	// 1-parameter private constructor.
	private ScoreAction(int pointsRewarded)
	{
		this.setPointsRewarded(pointsRewarded);
	}

	// Getter and setter methods for ScoreAction enumeration.

	public int getPointsRewarded() 
	{
		return this.pointsRewarded;
	}

	public void setPointsRewarded(int pointsRewarded) 
	{
		this.pointsRewarded = pointsRewarded;
	}
	
	@Override
	// toString method for the enumeration.
	public String toString()
	{
		return (this.name() + " + " + this.getPointsRewarded() + " points");
	}
}