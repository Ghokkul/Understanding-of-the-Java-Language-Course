import java.util.Random;

public class RugbyMatchTest {

	public static void main(String[] args) 
	{
		// Creates a new instance of RugbyMatch class. 
		//Brisban Broncos vs Melbourne Storm Rugby Matches.
		RugbyMatch match01 = new RugbyMatch(new RugbyScore("Brisbane Broncos"), new RugbyScore("Melbourne Storm"));
		
		// Creates a new instance of Random class.
		Random rand = new Random();
		
		// This loop is the for loop. 
		// This randomly generate seven score actions for both teams five times.
		for(int counter = 0; counter < 7; counter++)
		{
			//Generates random number
			match01.homeScore(ScoreAction.values()[rand.nextInt(4)]);
			match01.awayScore(ScoreAction.values()[rand.nextInt(4)]);
		}
		
		// Outputs the results of the match.
		System.out.println(match01);
	}
}
