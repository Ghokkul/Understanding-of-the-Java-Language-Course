public class RugbyMatch
{
	private RugbyScore home;
	private RugbyScore away; 
	
	// 1-parameter constructor for RugbyMatch class.
	public RugbyMatch(RugbyScore home, RugbyScore away) 
	{
		this.home = home;
		this.away = away;
	}

	// Getter and Setter methods for RugbyScore class.
	public RugbyScore getHome() {
		return home;
	}

	public void setHome(RugbyScore home) {
		this.home = home;
	}

	public RugbyScore getAway() {
		return away;
	}

	public void setAway(RugbyScore away) {
		this.away = away;
	}

	//Method to increment home score based using the score-action enum.
	public void homeScore(ScoreAction scoreType)
	{
		this.home.score(scoreType);
	}
	
	//Method to increment away score based using the score-action enum.
	public void awayScore(ScoreAction scoreType)
	{
		this.away.score(scoreType);
	}
	
	// Method to determine the winner of the match.
	public RugbyScore winner()
	{	
		RugbyScore winner = null;
		
		if(this.home.getPoints() > this.away.getPoints())
		{
			winner = this.home;
		}
		else if(this.home.getPoints() < this.away.getPoints())
		{
			winner = this.away;
		}
		
		return winner;
	}
	
	@Override
	// toString method that returns a message about the end result of the rugby match.
	public String toString()
	{
		String postGameMessage = null;
		
		// If conditions to determine the result of the game tie or win,
		// This will output the message depending on the end results of the game.
		if(winner() == null)
		{
			postGameMessage = (this.home.getName() + " tied with the " + this.away.getName() + " " + this.home.getPoints() + " points");
		}
		else if (winner().getName().equals(this.home.getName()))
		{
			postGameMessage = (this.home.getName() + " won over " + this.away.getName() + " " + this.home.getPoints() + " - " + this.away.getPoints());
		}
		else if (winner().getName().equals(this.away.getName()))
		{
			postGameMessage = (this.away.getName() + " won over " + this.home.getName() + " " + this.away.getPoints() + " - " + this.home.getPoints());
		}
		
		return postGameMessage;
	}
}