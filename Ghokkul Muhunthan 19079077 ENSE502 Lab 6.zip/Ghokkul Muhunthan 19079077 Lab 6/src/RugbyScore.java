public class RugbyScore 
{
	private String name;
	private int points;
	
	// 1-parameter constructor.
	public RugbyScore(String name) 
	{
		this.name = name;
		this.points = 0;
	}
	
	// Getter and Setter methods for RugbyScore class.
	public String getName() 
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public int getPoints() 
	{
		return points;
	}

	public void setPoints(int points) 
	{
		this.points = points;
	}

	// Method to increment points of the team.
	public void score(ScoreAction scoreType)
	{
		//This increment the team score.
		this.points += scoreType.getPointsRewarded();
	}

	
	@Override
	// toString method for RugbyScore class.
	public String toString()
	{
		return ("team: " + this.name + " points: " + this.points);
	}
}
