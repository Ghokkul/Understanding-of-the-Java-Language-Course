//Name: Ghokkul Muhunthan 
//Student ID: 19079077

public class Purchase {

	private String item; 
	private double price;
	
	public Purchase(String item, double price) 
	{
		this.setItem(item);
		this.setPrice(price);
	}
	
	public Purchase()
	{
		this.setItem("");
		this.setPrice(0);
	}
	
	
	public String getItem()
	{
		return item;
	}
	
	public void setItem(String item)
	{
		if(item.isEmpty() || item.equals(""))
		{
			this.item = "UNKNOWN";
		}
		else
		{
			this.item = item; 
		}
	}
	public double getPrice() 
	{
		return price;
	}
	
	public void setPrice(double price)
	{
		if(price < 0.00)
		{
			this.price = 0.00;
		}
		else
		{
			this.price = price; 
		}
	}

	public String toString()
	{

		return (String.format("%-22s", this.getItem())+ String.format("$%6.2f", this.getPrice()));
	}
}
