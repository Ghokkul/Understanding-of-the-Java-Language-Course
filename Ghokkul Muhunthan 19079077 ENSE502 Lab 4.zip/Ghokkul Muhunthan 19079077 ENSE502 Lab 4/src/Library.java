//Name: Ghokkul Muhunthan 
//Student ID: 19079077

public class Library {
	
	private Book[] inventory;
	private int capacity;
	
	public Library(int capacity) 
	{
		this.setCapacity(capacity);
		this.setInventory(this.inventory); 
	}

	public Book[] getInventory() 
	{
		return inventory;
	}
	
	public void setInventory(Book[] inventory) 
	{
		this.inventory = new Book[this.getCapacity()];
	}
	public int getCapacity() 
	{
		return capacity;
	}

	public void setCapacity(int capacity) 
	{
		if(capacity < 1)
		{
			this.capacity = 1;
		}
		else
		{
			this.capacity = capacity;	
		}
	}
	
	public boolean addBook(Book book)
	{
		boolean saveSuccess = false;
		
		for(int index = 0; index < this.inventory.length; index++)
		{
			if(this.inventory[index] == null)
			{
				this.inventory[index] = book;
				saveSuccess = true;
				
				return saveSuccess;
			}
		}
		
		return saveSuccess;
	}
	
	public Book borrow(String title)
	{
		Book temp = null;
		
		for(Book book : this.inventory)
		{
			if(title.equalsIgnoreCase(book.getTitle()))
			{
				temp = book;
				book.setBorrowed(true);
				
				return temp;
			}
		}
	
		return temp;
	}
	
	public String toString()
	{
		String message = "Contents of the library\n";
	
		for(int index = 0; index < this.inventory.length; index++)
		{
			message += (((index + 1) + ". " + this.inventory[index].toString() + "\n"));
		}
		
		return message;
	}
}
	
	

