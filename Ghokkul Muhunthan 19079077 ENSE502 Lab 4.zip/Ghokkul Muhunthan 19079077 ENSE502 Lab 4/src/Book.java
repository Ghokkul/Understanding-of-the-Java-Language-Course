//Name: Ghokkul Muhunthan 
//Student ID: 19079077

public class Book {
	
	private String title;
	private String author;
	private boolean isBorrowed;
	
	public Book(String title, String author)
	{
		this.setTitle(title);
		this.setAuthor(author);
		this.setBorrowed(false);
	}
	
	public String getTitle() 
	{
		return title;
	}
	public void setTitle(String title) 
	{
		this.title = title;
	}

	public String getAuthor() 
	{
		return author;
	}
	public void setAuthor(String author) 
	{
		this.author = author;
	}

	public boolean isBorrowed() 
	{
		return isBorrowed;
	}
	public void setBorrowed(boolean isBorrowed) 
	{
		this.isBorrowed = isBorrowed;
	}
	
	public String toString()
	{
		String bookDetails = null;
		
		if (isBorrowed)
		{
			bookDetails = (this.title + " By " + this.author + " is borrowed: Yes");
		}
		else
		{
			bookDetails = (this.title + " By " + this.author + " is borrowed: No");
		}
		
		return bookDetails;
	}

}
