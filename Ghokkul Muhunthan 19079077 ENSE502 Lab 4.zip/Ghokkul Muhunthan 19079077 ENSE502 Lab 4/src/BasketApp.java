//Name: Ghokkul Muhunthan 
//Student ID: 19079077

public class BasketApp {

	public static void main(String[] args) {
		
		Basket basket = new Basket(11);
		
		basket.addPurchase(new Purchase("Apples - 5 Pack", 15.00));
		basket.addPurchase(new Purchase("Orange - 5 Pack", 9.00));
		basket.addPurchase(new Purchase("Bread - 2 Loafs", 7.40));
		basket.addPurchase(new Purchase("Whitakers White Chocolate 250g", 4.50));
		basket.addPurchase(new Purchase("Muffins Mixed - 6 pack", 4.60));		
		
		basket.addPurchase(new Purchase("Meadow Fresh Milk 1 Litre", 3.25));
		basket.addPurchase(new Purchase("Maggi Super Noodles Instant 60g", 1.80));
		basket.addPurchase(new Purchase("Weet-Bix", 5.70));
		basket.addPurchase(new Purchase("Chicken Drumsticks", 6.00));
		basket.addPurchase(new Purchase("Avocadoes", 5.00));
		basket.addPurchase(new Purchase("Lettuce", 3.99));
		
		basket.printReceipt();
	}

}
