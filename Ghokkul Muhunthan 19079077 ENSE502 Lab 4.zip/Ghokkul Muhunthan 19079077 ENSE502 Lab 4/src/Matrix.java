//Name: Ghokkul Muhunthan 
//Student ID: 19079077

import java.util.Scanner;

public class Matrix {

	private int row; 
	private int col; 
	private int data[][];

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getCol() {
		return col;
	}

	public void setCol(int col) {
		this.col = col;
	}

	public int[][] getData() {
		return data;
	}

	public void setData(int[][] data) {
		this.data = data;
	}

	public Matrix(int row, int col)
	{
		this.row = row; 
		this.col = col; 
		data = new int[row][col];
	}
	
	public void insert()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter values in Matrix ");
		
		for(int i = 0; i<this.row; i++)
		{
			for(int j = 0; j<this.col; j++)
			{
				data[i][j] = sc.nextInt();
			}
		}
	}

	public Matrix add(Matrix a)
	{
		Matrix c = new Matrix(row, col);
		for(int i = 0; i<row; i++)
		{
			for(int j = 0; j<col; j++)
			{
				c.data[i][j] = this.data[i][j] + a.data[i][j];
			}
		}
		return c;
	}

	public Matrix multi(Matrix a)
	{
		Matrix c = new Matrix(this.row, a.col);
		
		for(int i = 0; i<c.col; i++)
		
			for(int j = 0; j<this.col; j++)
			{
				for(int k = 0; k<this.col; k++)
				{
					c.data[i][j] += (this.data[i][j] * a.data[k][j]);
				}
			}
		
		return c; 
	}
	
	public void print()
	{
		for(int i = 0; i<this.row; i++)
		{
			for(int j = 0; j<this.col; j++)
			{
				System.out.println( data[i][j] + " ");
			}
			System.out.println();
		}
	}
	}
