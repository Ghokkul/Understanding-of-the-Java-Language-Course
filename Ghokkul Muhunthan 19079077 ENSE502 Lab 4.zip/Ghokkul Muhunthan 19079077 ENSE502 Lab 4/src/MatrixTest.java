//Name: Ghokkul Muhunthan 
//Student ID: 19079077

import java.util.*;

public class MatrixTest {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Matrix Number One : Enter number of rows and column");
		int row = scan.nextInt();
		int col = scan.nextInt();
		Matrix A = new Matrix(row,col);
		A.insert();
		
		System.out.println("Matrix Number Two: Enter number of rows and column");
		int row1 = scan.nextInt();
		int col1 = scan.nextInt();
		Matrix B = new Matrix(row1,col1);
		B.insert();
		
		System.out.println("ADDITION");
		Matrix C = A.add(B);
		C.print();
		
		System.out.println("MULTIPLCATION");
		C=A.multi(B);
		C.print();
		System.out.println();
	}

}
