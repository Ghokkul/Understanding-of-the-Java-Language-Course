//Name: Ghokkul Muhunthan 
//Student ID: 19079077

public class Basket 
{
	private Purchase[] pList;
	private int nPurchases;
	private int purchaseLog;
	
	public Basket(int n) 
	{
		this.setNPurchases(n);
		this.setPList(this.pList);
		this.purchaseLog = 0;
	}
	
	public Purchase[] getPurchases() 
	{
		int currentItems = 0;
		
		for(Purchase purchase : this.pList)
		{
			if(purchase != null)
			{
				currentItems++;
			}
		}
		
		Purchase[] currentPurchases = new Purchase[currentItems];
		
		int extIndex = 0;
		
		for(Purchase purchase : this.pList)
		{
			if(purchase != null)
			{
				currentPurchases[extIndex++] = purchase;
			}
		}
	
		return currentPurchases;
	}

	public void setPList(Purchase[] pList) 
	{
		this.pList = new Purchase[this.getNPurchases()];
	}
	public int getNPurchases() 
	{
		return nPurchases;
	}

	public void setNPurchases(int nPurchases) 
	{
		if(nPurchases <= 0)
		{
			this.nPurchases = 10;
		}
		else
		{
			this.nPurchases = nPurchases;			
		}
	}

	public void addPurchase(Purchase p)
	{	
		if (this.purchaseLog == this.getNPurchases())
		{
			System.out.println("Insufficient memory to save this purchase.\n" + "Please allocate more memory for the array.");
		}
		else if (this.purchaseLog < this.getNPurchases())
		{
			this.pList[this.purchaseLog++] = p;
		}
	}
	
	public Purchase getMostExpensive()
	{
		Purchase priciestItem = null;
		double highest = Double.MIN_VALUE; 
				
		for(Purchase item : this.pList)
		{
			if(item.getPrice() > highest)
			{
				highest = item.getPrice();
				
				priciestItem = item;
			}
		}
		
		return priciestItem;
	}

	public void printReceipt()
	{
		for(int count = 0; count <= 28; count++)
		{
			System.out.printf("-");
		}
		System.out.printf("\n");
		
		System.out.printf("%-22s %6s\n", "Item", "Price");
		
		for(int count = 0; count <= 28; count++)
		{
			System.out.printf("-");
		}
		System.out.printf("\n");
		
		for(Purchase item : this.pList)
		{
			System.out.println(item);
		}
		
		for(int count = 0; count <= 28; count++)
		{
			System.out.printf("=");
		}
		System.out.printf("\n");
		
		System.out.printf("%22s$%s\n", "GRAND TOTAL: ", String.format("%6.2f", this.total()));
	
 		for(int count = 0; count <= 28; count++)
		{
			System.out.printf("=");
		}
		System.out.printf("\n");
	}
	
	public double total()
	{
		double grandTotal = 0;
		
 		for(Purchase item : this.pList)
		{
 			grandTotal += item.getPrice();
		}
		
 		return grandTotal;
	}
}
