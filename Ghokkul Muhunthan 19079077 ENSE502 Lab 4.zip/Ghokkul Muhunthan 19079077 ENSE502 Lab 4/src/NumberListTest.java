//Name: Ghokkul Muhunthan 
//Student ID: 19079077

import java.util.Random;

public class NumberListTest 
{
	public static void main(String[] args) 
	{
		NumberList test = new NumberList();
		Random rand = new Random();
	
		for(int index = 0; index < test.size(); index++)
		{			
			test.update(index, (rand.nextInt(21) - 10));	
		}
		
		System.out.println(test);
		
		
		System.out.println(" Object's Statistics ");
		System.out.println("Min: " + test.min());
		System.out.println("Max: " + test.max());
		System.out.println("Average: " + test.average());
		System.out.println("Non-zero Values: " + test.nonZero());
		System.out.println("Object\'s Elements: " + test.size());
		int elementIndex = 0;
		System.out.printf("Element [%d] Holds: %d\n", elementIndex, test.getNumber(elementIndex));
		
		System.out.println("Original:   " + test);
		
		int factor = 2;
		test.scale(factor);
		System.out.printf("Scaled (x%d):%s\n", factor, test);
		
		test.absolute();
		System.out.println("Absolute:   " + test);
	
		NumberList testSub = test.sub(2, 4);
		System.out.println("Subbed:     "+ testSub);
	}

}
