//Name: Ghokkul Muhunthan 
//Student ID: 19079077

import java.util.Arrays;

public class NumberList 
{ 
	private int[] intList; 
		
	public NumberList() 
	{
		this.intList = new int[10];
		
		Arrays.fill(this.intList, 0);
	}

	public int getIntList(int i) 
	{
		return (this.intList[valid(i)?i:0]);
	}

	
	public void setIntList(int[] intList) 
	{
		this.intList = intList;
	}
	
	public void update(int index, int value)
	{
		if (valid (index))
		{
			this.intList[index] = value; 
		}
	}
	
	public int size()
	{
		return (this.intList.length);
	}
	
	
	public void absolute()
	{
		for(int index = 0; index < this.intList.length; index++)
		{
			this.intList[index] = Math.abs(this.intList[index]);
		}
	}
	
	
	public double average()
	{
		double average = 0.0; 
		
		for(int number : this.intList)
		{
			average += number; 
		}
		
		return (average / this.intList.length);
	}
	
	public int max()
	{
		int highest = Integer.MIN_VALUE;
		
		for(int number : this.intList)
		{
			if(number > highest)
			{
				highest = number; 
			}
		}
		return highest; 
	}
	
	public int min()
	{
		int lowest = Integer.MAX_VALUE;
		
		for(int number : this.intList)
		{
			lowest = number; 
		}
		return lowest; 
	}
	
	
	public int nonZero()
	{
		int count = 0;

		for(int number: this.intList)
		{
			if(number != 0)
			{
				count++; 
			}	
		}
		
		return count; 
	}
	
	public void scale(int f)
	{
		for(int index = 0; index < this.intList.length; index++)
		{
			this.intList[index] *=f;
		}
	}
	
	public NumberList sub(int startIndex, int endIndex)
	{
		NumberList temp = new NumberList();
		
		if(valid(startIndex) && valid(endIndex))
		{
			int indexTemp = 0;
			
			for(int index = startIndex; index <= endIndex; index++)
			{
				temp.update(indexTemp++, this.intList[index]); 
			}
		}
		
		return temp;
	}
	
	private boolean valid(int i) 
	{
		boolean validIndex = false;
		
		if(i >= 0 && i < this.intList.length)
		{
			validIndex = true;
		}
		return validIndex;
	}
	
	public String toString()
	{
		String numberString = "[";
		
		for(int index = 0; index < (this.intList.length - 1); index++)
		{
			numberString += (String.format("%3s", this.intList[index]) + ","); 
		}
		
		numberString += (String.format("%3s", this.intList[this.intList.length - 1]) + "]");
	
		return numberString;
	}

	public Object getNumber(int elementIndex) 
	{
 	return null;
	}
}
