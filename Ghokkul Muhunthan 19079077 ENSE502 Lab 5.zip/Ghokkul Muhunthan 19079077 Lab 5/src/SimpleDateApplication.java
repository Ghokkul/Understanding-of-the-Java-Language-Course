import java.time.LocalDate;
import java.util.Scanner;
import java.util.StringTokenizer;

public class SimpleDateApplication {

	public static void main(String[] args) 
	{
		//Using the code snippet from the exercise brief
		SimpleDate d1 = new SimpleDate();
		d1.setDay(3);
		d1.setMonth(4);
		d1.setYear(2022);
		System.out.println(d1);
		SimpleDate d2 = new SimpleDate(4,3,2022);
		System.out.println(d2);
		
		// Today's date.
		LocalDate year = LocalDate.now();
		System.out.println("Today's date: " + year);
				
		   Scanner scanner = new Scanner(System.in);
		   SimpleDate userData = userDate(scanner);
		   System.out.println(userData);
			
		}
			
			public static SimpleDate userDate(Scanner scanner)
			{
				SimpleDate temp = new SimpleDate();
				
				//Asking user to enter the date.
				System.out.println("\nAsking the user to enter a date (DD/MM/YY):");
				String userInput = scanner.nextLine();
				
				//Using the StringTokenizer to extract day, month, and year from String. 
				StringTokenizer tokenizer = new StringTokenizer(userInput, "/-.,");
				
				String token = tokenizer.nextToken();
				temp.setDay((int)Double.parseDouble(token));
				
				token = tokenizer.nextToken();
				temp.setMonth((int)Double.parseDouble(token));
				
				token = tokenizer.nextToken();
				temp.setYear((int)Double.parseDouble(token));
				
				return temp;
			}
		
	}


