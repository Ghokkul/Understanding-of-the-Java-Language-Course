public class Redact {
	
	private static String text; 
	
	public Redact(final String[] text)
	{
		Redact.text = "The secret tomato sauce ingredients are:  onions, carrots, garlic, whole "
					+ "tomatoes, salt, tomato paste and olive oil.";
		
		return;
	}

	public static String getText()
	{
		return text;
	}

	public static void setText(String text) 
	{
		Redact.text = text;
	}
	
	
	public static void main(String[] args)
	{
		
		Redact.setText("The secret tomato sauce ingredients are: onions, carrots, garlic, whole"
				        + "tomatoes, salt, tomato paste and olive oil.");
		
		System.out.println(Redact.getText());
		
		System.out.println("Outputted Version: "+Redact.getText().replaceAll("secret", "_")
				                                                 .replaceAll("tomato", "_")
				                                                 .replaceAll("ol", "_")
				                                                 .replace('a', '_'));
	}	
}

