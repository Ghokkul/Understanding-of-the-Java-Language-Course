import java.time.LocalDate;

public class SimpleDate {

	private int day; 
	private int month; 
	private int year; 
	
	public SimpleDate(int day, int month, int year) 
	{
		this.setDate(day, month, year);
	}

	public SimpleDate()
	{
		this.setDate(0,0,0);
	}
	public void setDate(int day, int month, int year)
	{
		this.setDay(day);
		this.setMonth(month);
		this.setYear(year);
	}

	//Getter and Setter Methods
	public int getDay() 
	{
		return day;
	}

	public void setDay(int day) 
	{
		//To validate day.
		if(day>=1 && day<=31)
		{
			this.day = day;			
		}
		else
		{
			this.day = 1; 
		}
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) 
	{
		//To validate month
		if(month >=1 && month <=12)
		{
			this.month = month;	
		}
		else
		{
			this.month = 1; 
		}
	}

	public int getYear()
	{
		return year;
	}

	public void setYear(int year) 
	{
		//If and else statement
		if(year >= 2000 && year <= LocalDate.now().getYear())
		{
			this.year = year;		
		}
		else
		{
			this.year = 2000; 
		}
	}
	
	//toString method
	public String toString()
	{
		String date; 
		date = (String.format("%02d", this.getDay()) + "/");
		date += (String.format("%02d", this.getMonth()) + "/");
		date += (this.getYear());	
		
		return date; 
	}
	
	

}
