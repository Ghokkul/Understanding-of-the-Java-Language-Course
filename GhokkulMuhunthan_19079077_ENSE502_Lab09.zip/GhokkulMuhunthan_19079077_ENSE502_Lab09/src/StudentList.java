import java.util.ArrayList;

public class StudentList
{
	private ArrayList<Student> studentList;

	// Zero-parameter default constructor for StudentList class.
	public StudentList() 
	{
		// Creates a new instance of an ArrayList of typed Student.
		this.studentList = new ArrayList<Student>();
	}
	
	public void add(Student student)
	{
		this.studentList.add(student);
	}
	
	public ArrayList<Student> enrolledIn(String paperCode)
	{
		
		ArrayList<Student> temp = new ArrayList<Student>();
		
		// For each loop to iterate through studentList ArrayList.
		for(Student student:this.studentList)
		{
			if(student.getPaperCodes().contains(paperCode))
			{
				// Adds the student to temp ArrayList.
				temp.add(student);
			}
		}
		return temp;
	}
}
