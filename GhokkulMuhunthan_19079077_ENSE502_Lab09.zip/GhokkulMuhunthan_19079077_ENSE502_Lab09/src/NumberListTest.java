public class NumberListTest 
{
	public static void main(String[] args) 
	{
		Numbers numbersList = new Numbers(); 
		
		//For loop to populate the list with ten numbers 1 to 10.
		for(int counter = 1; counter <=10; counter++)
		{
			numbersList.addNumber(counter);
		}
		
		//Outputs the populated list.
		System.out.println("Populated List: ");
		numbersList.printList();
		
		System.out.println("Min: "+numbersList.min());
		System.out.println("Max: "+numbersList.max());
		
		numbersList.clear();
		System.out.println("Cleared List: ");
		numbersList.printList();
	}

}
