public class StudentListTest 
{
	public static void main(String[] args) 
	{
		StudentList studentList = new StudentList();
		
		studentList.add(new Student("Dave", "ENSE502")); //student one.
		studentList.add(new Student("Joe", "COMP501"));	 //student two.
		studentList.add(new Student("Jeff", "ENSE502")); //student three.
		studentList.add(new Student("Sam", "ENSE502"));  //student four.
		studentList.add(new Student("John", "ENSE502")); //student five
		
		System.out.println("Student List!");
		System.out.println(studentList.enrolledIn("ENSE502"));
	}
}
