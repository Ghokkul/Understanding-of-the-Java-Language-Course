public class Student 
{
	private String name; 
	private String paperCodes;
	
	// 2-parameter constructor for Student class.
	public Student(String name, String paperCodes) 
	{
		this.setName(name);
		this.setPaperCodes(paperCodes);
	}
	
	// Getter and Setter methods.
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = (name.isEmpty()? "UNKNOWN":name);
	}

	public String getPaperCodes() 
	{
		return paperCodes;
	}

	public void setPaperCodes(String paperCodes) 
	{
		this.paperCodes = (paperCodes.isEmpty()? "UNKNOWN":paperCodes);
	}
	
	@Override
	// toString method for Student class that returns the name of the student.
	public String toString()
	{
		return (this.getName());
	}
}
