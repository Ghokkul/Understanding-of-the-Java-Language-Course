import java.util.ArrayList;

public class Numbers 
{
	private ArrayList<Integer> list; 
	
	//Zero-parameter default constructor.
	public Numbers() 
	{
		this.list = new ArrayList<Integer>();
	}
	
	public void addNumber(Integer i)
	{
		this.list.add(i);
	}
	
	public void clear()
	{
		this.list.clear();
	}

	public Integer min()
	{
		//Initializes minimum to the largest number.
		Integer min = Integer.MAX_VALUE;
		
		//For each loop to iterate though this.list.
		for(Integer value: this.list)
		{
			//Check if current element is smaller than minimum.
			if(value < min)
			{
				//updates minimum value.
				min = value; 
			}
		}
		return min; 
	}
	
	public Integer max()
	{
		//Initializes minimum to the smallest integer.
		Integer max = Integer.MIN_VALUE;
		
		//For each loop to iterate though this.list.
		for(Integer value: this.list)
		{
			//If statement to check if current element is 
			//smaller than maximum.
			if(value > max)
			{
				//Updates maximum value.
				max = value; 
			}
		}
		return max; //return max
	}
	
	public void printList()
	{
		//Now it will output the list.
		System.out.println(this.list);
	}
}
