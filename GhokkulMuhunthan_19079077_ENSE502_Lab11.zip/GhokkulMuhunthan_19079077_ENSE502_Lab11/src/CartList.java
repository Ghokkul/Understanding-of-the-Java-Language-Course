import java.util.ArrayList;
import java.util.Arrays;

public class CartList 
{
	private ArrayList<String> wishlist;
	private ArrayList<String> checkout;
	
	public CartList()	
	{
		this.wishlist = new ArrayList<String>(Arrays.asList(new String[]
					{"Clothes", "Books", "Coffee", "Music"}));
		this.checkout = new ArrayList<String>();
	}

	public ArrayList<String> getWishlist() 
	{
		return wishlist;
	}

	public ArrayList<String> getCheckout() 
	{
		return checkout;
	}
	
	public void moveLeft(int index)
	{
		this.wishlist.add(this.checkout.remove(index));
	}

	public void moveRight(int index)
	{
		this.checkout.add(this.wishlist.remove(index));
	}
}
