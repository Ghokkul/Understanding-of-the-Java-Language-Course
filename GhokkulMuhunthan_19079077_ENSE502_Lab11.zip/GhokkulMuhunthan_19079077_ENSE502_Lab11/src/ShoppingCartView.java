import java.awt.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class ShoppingCartView extends JPanel
{
	private CartList model; 
	
	private JLabel leftLabel, rightLabel;
	private JList leftList, rightList;
	private JButton rightButton, leftButton;
	
	public ShoppingCartView(CartList model)
	{
		this.model = model;
		
		setLayout(null);
		
		leftLabel = new JLabel("Wishlist");
		leftLabel.setLocation(10, 5);
		leftLabel.setSize(150, 20);
		leftLabel.setHorizontalAlignment(SwingConstants.CENTER);
		add(leftLabel);
		
		leftList = new JList();
		JScrollPane leftScrollPane = new JScrollPane(leftList, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
		ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		leftScrollPane.setLocation(10, 30);
		leftScrollPane.setSize(150, 150);
		add(leftScrollPane);
		
		rightButton = new JButton("=>");
		rightButton.setLocation(200, 60);
		rightButton.setSize(50, 30);
		add(rightButton);

		leftButton = new JButton("<=");
		leftButton.setLocation(200, 120);
		leftButton.setSize(50, 30);
		add(leftButton);

		rightLabel = new JLabel("Checkout");
		rightLabel.setLocation(290, 5);
		rightLabel.setSize(150, 20);
		rightLabel.setHorizontalAlignment(SwingConstants.CENTER);
		add(rightLabel);
		
		rightList = new JList();
		JScrollPane rightScrollPane = new JScrollPane(rightList, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
		ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		rightScrollPane.setLocation(290, 30);
		rightScrollPane.setSize(150, 150);
		add(rightScrollPane);
		
		setPreferredSize(new Dimension(450, 190));
		update();
	}
	
	public JList getLeftList() 
	{
		return leftList;
	}

	public JButton getRightButton() 
	{
		return rightButton;
	}
	
	public JButton getLeftButton() 
	{
		return leftButton;
	}
	
	public JList getRightList() 
	{
		return rightList;
	}
	
	@SuppressWarnings("unchecked")
	public void update()
	{
		int leftSelection = leftList.getSelectedIndex();
		int rightSelection = rightList.getSelectedIndex();
		
		leftList.setListData(model.getWishlist().toArray());
		rightList.setListData(model.getCheckout().toArray());

		leftList.setSelectedIndex(leftSelection);
		rightList.setSelectedIndex(rightSelection);
		
		rightButton.setEnabled(model.getWishlist().size() > 0);
		leftButton.setEnabled(model.getCheckout().size() > 0);
	}
}
