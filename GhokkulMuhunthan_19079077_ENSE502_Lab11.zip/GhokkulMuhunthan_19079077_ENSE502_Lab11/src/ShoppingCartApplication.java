import java.awt.event.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class ShoppingCartApplication extends JFrame
{
	private CartList model;
	private ShoppingCartView view;

	public ShoppingCartApplication(String title)
	{
		super(title);
		
		setSize(465, 228);
		setResizable(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		model = new CartList();
		view = new ShoppingCartView(model);
		
		getContentPane().add(view);
		
		view.getRightButton().addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(view.getLeftList().getSelectedIndex() != -1)
				{
					model.moveRight(view.getLeftList().getSelectedIndex());
					
					view.update();
				}
			}
		});
		
		view.getLeftButton().addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(view.getRightList().getSelectedIndex() != -1)
				{
					model.moveLeft(view.getRightList().getSelectedIndex());
					
					view.update();
				}
			}
		});
	}
	
	public static void main(String[] args) 
	{
		JFrame frame = new ShoppingCartApplication("Shopping Cart");
	
		frame.setVisible(true);
	}
}
