import java.util.InputMismatchException; 
import java.util.Scanner; 

public class ComputeProduct
{ 
	private static Scanner scanner; 
 
 public static void product() throws InputMismatchException
 { 
	 System.out.println("Welcome to the calculator.");
	 System.out.println("1. Compute product");
	 System.out.println("2. quit");
	 
	 while(true)
	 {
		 String op;
		 Scanner chooseOption = new Scanner(System.in);
		 op = chooseOption.next(); 
		 try
		 {
			 if(op.equals("1"))
			 {
				 System.out.println("Enter first number:"); 
				 int value1 = scanner.nextInt(); 
				  
				 System.out.println("Enter second number:"); 
				 int value2 = scanner.nextInt(); 
				 				 
				 System.out.println("Product is: "+(value1*value2)); 
			 }	
			 else if(op.equals("2"))
			 {
				 System.out.println("Goodbye!");
				 break; 
			 }
			 else if (!op.equals("1") || !op.equals("2"))
			 {
				 System.out.println("Invalid Menu Input. Please try again.");
			 }
		
		 }catch(InputMismatchException ex)
		 {
			 System.out.println("Error reading integer value ");
			 break;
		 }
		 
		 System.out.println("Welcome to the calculator.");
		 System.out.println("1. Compute product");
		 System.out.println("2. quit");
	 }
 } 
 
 public static void main(String args[])
 { 
	 scanner = new Scanner(System.in);   
	 product();   
 } 
} 
