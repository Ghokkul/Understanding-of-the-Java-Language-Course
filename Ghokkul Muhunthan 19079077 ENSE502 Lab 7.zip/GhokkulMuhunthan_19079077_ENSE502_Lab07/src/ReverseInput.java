import java.util.*;

public class ReverseInput {
	
	public static void main(String[] args) 
	{
		Stack<Integer> stack = new Stack<Integer>();
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Ask user to enter numbers and press quit to terminate program!");
		
		do
		{
			System.out.print("Test: \n");
		}
		while(pushData(stack, scanner));
		
		System.out.println("Stop Program");
		scanner.close();

		System.out.println("\nStack Holds: " +  stack);
		
		//Testing to see if the numbers are reversed.
		System.out.print("The orginal stack is now reversed : [");
		for(int index = stack.size(); index > 1; index--)
		{
			System.out.print(stack.pop() + ", ");
		}
		System.out.print(stack.pop() + "]");
	}

	public static boolean pushData(Stack<Integer> stack, Scanner scanner)
	{
		String keyboardInput = scanner.next();
	
		if(keyboardInput.equalsIgnoreCase("quit"))
		{

			return false;
		}
		stack.push(Integer.parseInt(keyboardInput));
		
		return true;
	}
}
