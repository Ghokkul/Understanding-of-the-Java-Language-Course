//Name: Ghokkul Muhunthan Student ID: 19079077
//This program is done by the help of Lecture Slides Week 7
//As it says on the Exercise Brief.
public class LinkedList 
{
	//LinkedList variables.
	private Integer number; 
	private LinkedList next; 
	private LinkedList prev; 
	
	public LinkedList(Integer number) 
	{
		this.number = number; 
		this.next = null; 
		this.prev = null; 
	}
	
	public void add(Integer number)
	{
	if(this.next==null)
	{
		LinkedList next = new LinkedList(number);
		this.next = next;
		next.prev = this;
	}
	else
	{
		this.next.add(number);
	}
	}
	
	//length of linked list
	public int length()
	{
		if(this.next == null)
		{
			return 1; 
		}
		return 1+this.next.length();
	}
	
	//text description of linked list
	public String text_Description()
	{
		if(this.next == null)
		{
			return this.number+"";
		}
		return this.number+", "+this.next.toString();
	}
	
	//finding number in the linked list
	public LinkedList find(Integer value)
	{
		if(this.number == value)
		{
			return this;
		}
		if(this.next == null)
		{
			return null;
		}
		return this.next.find(value);
		}
	}	
