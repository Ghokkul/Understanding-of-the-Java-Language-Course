import java.util.Scanner;
import java.util.Stack;

public class IntegerStackTest 
{
		public static void main(String[] args) 
		{
			Stack<Integer> stack = new Stack<Integer>();
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("Ask user to enter numbers and press quit to terminate program!");
			
			do
			{
				System.out.print("\nTest: ");
			}
			while(pushData(stack, scanner));
			
			System.out.println("Stop Program");
			scanner.close();

			System.out.println("\nStack List: " +  stack);
		}
		
		public static boolean pushData(Stack<Integer> stack, Scanner scanner)
		{
			String keyboardInput = scanner.next();
		
			if(keyboardInput.equalsIgnoreCase("quit"))
			{

				return false;
			}
			stack.push(Integer.parseInt(keyboardInput));
			
			return true;
		}
}
