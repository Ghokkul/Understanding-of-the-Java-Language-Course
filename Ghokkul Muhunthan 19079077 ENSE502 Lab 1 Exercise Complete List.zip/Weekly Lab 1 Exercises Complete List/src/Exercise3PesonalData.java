
public class Exercise3PesonalData {

	public static void main(String[] args) {
		System.out.println("Name: Ghokkul Muhunthan");
		System.out.println("Birthday: July 8");
		System.out.println("Interests: Sports, Programming, Music");
		System.out.println("Favorite book: Kingdom of Fantasy");
		System.out.println("Favorite film: Frozen");
	}

}
