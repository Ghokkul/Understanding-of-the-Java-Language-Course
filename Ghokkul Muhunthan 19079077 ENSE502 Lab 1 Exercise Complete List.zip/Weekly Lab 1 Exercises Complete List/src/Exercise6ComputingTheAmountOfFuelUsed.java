import java.util.*;

public class Exercise6ComputingTheAmountOfFuelUsed {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in); 
      	
		System.out.println("Enter the number of miles: ");
      	double miles = scan.nextDouble(); 
      	
      	System.out.println("Enter the gallons of fuel used: ");
      	double gallons= scan.nextDouble(); 
      	
      	double mpg=miles/gallons; 
      	System.out.println("Miles Per Gallons: "+mpg);
	}

}
