import java.util.*;

public class Exercise7TimeDuration {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int days = 0; 
		int hours = 0; 
		int minutes = 0; 
		int seconds = 0; 
		
		System.out.println("Enter the nubmer of hours");
		hours = input.nextInt();
		
		System.out.println("Enter the number of minutes");
		minutes = input.nextInt();
				
		System.out.println("Enter the number of seconds");
		seconds = input.nextInt();
		
		hours +=(days*24);
		minutes += (hours*60);
		seconds += (minutes*60);
		
		System.out.println("The total number of seconds: "+seconds);
		
	}


}
