import java.util.*;
public class Exercise4Division {

	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		System.out.println("Please enter the numerator ");
		double numerator = input.nextInt();
		System.out.println("Please enter the denominator ");
		double denominator = input.nextInt();

		char inputdivisionsymbol = '/';
				
		int myNumerator = (int) numerator; 
		int myDenominator = (int) denominator;
		
		System.out.println("The input fraction is: "+myNumerator +inputdivisionsymbol +myDenominator);
		
		
		double divider  = (numerator/denominator);		
		
		if(denominator == 0)
		{
			System.out.println("The quantity is undefined");
			return; 
		}
		
		System.out.println("The decimal equivalence is: "+divider);
		
	}

}
