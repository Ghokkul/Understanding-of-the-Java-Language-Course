import java.util.*;

public class Exercise1PrintAMessage {

	public static void main(String[] args) {
		System.out.println("What is the message? ");
		Scanner message = new Scanner(System.in);
		String str = message.nextLine();
		char singleQuotesChar = '"';
		char fullstop = '.';
		System.out.println("The message is  " +singleQuotesChar +str +singleQuotesChar +fullstop);
	}
}
