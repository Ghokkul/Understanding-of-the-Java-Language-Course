import java.util.*;
public class Exercise5ConvertMilesToKilometeres {

	public static void main(String[] args) {
		double miles = 0; 
		
		final double MILES_TO_KILOMETER = 1.609;
		
		Scanner newscan = new Scanner(System.in);
		
		System.out.println("Enter the number of miles: ");
		miles = newscan.nextDouble();
		
		if(miles < 0)
		{
			System.out.println("Please enter a value greater than 0!.");
			return;
		}
		
		System.out.println("The number of kms is: "+ (miles * MILES_TO_KILOMETER));
		
	}
}
