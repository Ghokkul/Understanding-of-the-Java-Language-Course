import java.util.*;
public class Exercise2ThreeNumberAverage {

	public static void main(String[] args) {
		
		double num = 0; 
		double x = 1; 
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter first number: ");
		double num1 = scan.nextDouble();
		System.out.println("Enter second number: ");
		double num2 = scan.nextDouble();
		System.out.println("Enter third number: ");
		double num3 = scan.nextDouble();
		
		System.out.println("The average of the numbers is: "+ (num1 + num2 + num3) / 3);
		
	}

}
