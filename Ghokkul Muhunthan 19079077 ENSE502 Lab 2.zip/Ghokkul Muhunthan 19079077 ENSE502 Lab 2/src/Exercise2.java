import java.util.*;

public class Exercise2 {

	//Calling third parameter constructor
	public boolean Calling_Constructor_Third (String firstname, String lastname,int studentID)
	{
		System.out.println("Calling 3rd parameter constructor");
		System.out.println("Student's first name: "+firstname+ "last name:  Perman ID: "+studentID);
	
		return true;
		
	}	
	
	//Calling second parameter constructor
	public boolean Calling_Constructor_Second(String firstname)
	{
		System.out.println("Calling 2nd parameter constructor");
		System.out.println("Student's firstname: "+firstname+ "last name: Perman ID: ? ");
		
		return true;
	}
	
	//Calling zero parameter constructor
	public boolean Calling_Constructor_zero()
	{
		System.out.println("Calling zero parameter constructor");
		System.out.println("Student's first name: UNKNOWN last name: UNKNOWN ID: ?");
		
		return true;
	}
	
	public class Student
	{
		String firstname; 
		String lastname; 
		int studentID;
		
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public int getStudentID() {
			return studentID;
		}
		public void setStudentID(int studentID) {
			this.studentID = studentID;
		} 
		
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter student's first name:");
		String firstname = sc.nextLine();
		
		System.out.println("Please enter student's last name:");
		String lastname = sc.nextLine();
		
		System.out.println("Please enter student's ID:");
		int studentID = sc.nextInt();
		
		//Printing third parameter constructor
		Exercise2 myObj = new Exercise2();
		System.out.print(myObj.Calling_Constructor_Third(firstname, lastname, studentID));
		System.out.println("\n");

		//Printing second parameter constructor 
		System.out.println(myObj.Calling_Constructor_Second(firstname));
		System.out.println("\n");

		//Printing zero parameter constructor 
		System.out.println(myObj.Calling_Constructor_zero());
		System.out.println("\n");
		

	}

}
