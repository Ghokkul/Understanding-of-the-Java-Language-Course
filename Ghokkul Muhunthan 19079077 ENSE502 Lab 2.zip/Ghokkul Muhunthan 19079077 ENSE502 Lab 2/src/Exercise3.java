import java.util.Scanner;

public class Exercise3 {
	
	public class Person {
		 int age; 
		double weight; 
		boolean student; 
		char gender;
		
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public double getWeight() {
			return weight;
		}
		public void setWeight(double weight) {
			this.weight = weight;
		}
		public boolean isStudent() {
			return student;
		}
		public void setStudent(boolean student) {
			this.student = student;
		}
		public char getGender() {
			return gender;
		}
		public void setGender(char gender) {
			this.gender = gender;
		} 
		
		
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter the person�s age:");
		int age = sc.nextInt();
		
		System.out.println("Please enter the person�s weight:");
		double weight = sc.nextDouble();
		
		System.out.println("Is the person a student (true/false):");
		boolean student = sc.nextBoolean();
		
		System.out.println("Please enter the person�s gender (M/F):");
		char gender = sc.next().charAt(0);
		
		System.out.println("Person: age:"+age+ " weight: "+weight+ " retired: "+student+ " gender: "+gender);
	}
	}
}
