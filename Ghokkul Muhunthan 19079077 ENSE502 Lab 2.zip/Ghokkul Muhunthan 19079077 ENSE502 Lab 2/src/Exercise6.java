import java.util.*;

public class Exercise6 {

	public class distance
	{
		double x1 = 0; 
		double x2 = 0; 
		double y1 = 0; 
		double y2 = 0; 
		double calculating_distance;
		static double distance;
		
		public double getX1() {
			return x1;
		}
		public void setX1(double x1) {
			this.x1 = x1;
		}
		public double getX2() {
			return x2;
		}
		public void setX2(double x2) {
			this.x2 = x2;
		}
		public double getY1() {
			return y1;
		}
		public void setY1(double y1) {
			this.y1 = y1;
		}
		public double getDistance() {
			return distance;
		}
		public void setDistance(double distance) {
			this.distance = distance;
		} 
		
		public distance(double x1, double y1, double x2, double y2)
		{
			calculating_distance = Math.sqrt(Math.pow(x2-x1, 2)+ (Math.pow(y2-y1,2)));	
		}
	}

	//Inputting it manually 
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter X1 coordinates: ");
		double x1 = sc.nextDouble();
		
		System.out.println("Enter Y1 coordinates: ");
		double y1 = sc.nextDouble();
		
		System.out.println("Enter X2 coordinates: ");
		double x2 = sc.nextDouble();
		
		System.out.println("Enter Y2 coordinates: ");
		double y2 = sc.nextDouble();
		if(x1 > 0 && x2> 0)
		{
			System.out.println("True");
		}else if(x1 < 0 && x2 < 0)
		{
			System.out.println("False");
		}
		
		if(y1 > 0 && y2> 0)
		{
			System.out.println("True");
		}else if(y1 < 0 && y2 < 0)
		{
			System.out.println("False");
		}
		
		double distance = Math.sqrt(Math.pow(x2-x1, 2)+ (Math.pow(y2-y1,2)));	
		
		System.out.println("The distance is: "+distance);
		

	}	
}