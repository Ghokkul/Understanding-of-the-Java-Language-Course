import java.util.*;

public class Exercise1 {

	public class Book
	{
		String title; 
		String author; 
		int numberOfPages;
		
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getAuthor() {
			return author;
		}
		public void setAuthor(String author) {
			this.author = author;
		}
		public int getNumberOfPages() {
			return numberOfPages;
		}
		public void setNumberOfPages(int numberOfPages) {
			this.numberOfPages = numberOfPages;
		} 
		
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter the title of the book ");
		String title = sc.nextLine();
		
		System.out.println("Please enter the author name");
		String author = sc.nextLine();
	
		System.out.println("Please enter the number of pages");
		int numberOfPages = sc.nextInt();
		
		while(numberOfPages <= 0)
		{
			System.out.println("Please enter the number of pages");
			numberOfPages = sc.nextInt();	
			
			if(numberOfPages > 0)
			{
				System.out.println("The book title is: "+title);
				System.out.println("The book author is: "+author);
				System.out.println("The book has "+numberOfPages+ " pages ");
				return; 
			}
		}
		
		System.out.println("The book title is: "+title);
		System.out.println("The book author is: "+author);
		System.out.println("The book has "+numberOfPages+ " pages "); 
	}

}