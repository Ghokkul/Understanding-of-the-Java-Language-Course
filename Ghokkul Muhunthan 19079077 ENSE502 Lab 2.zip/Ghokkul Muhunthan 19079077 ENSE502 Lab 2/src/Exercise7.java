//EXERCISE 7 EXERCISE 7 EXERCISE 7 

public class Exercise7 {

	private double balance; 
	
	//Set balance to 0.00 
	public Exercise7() {
		balance = 0.0; 
	}
	
	//Deposit 
	public void deposit(double amount)
	{
		balance = balance + amount; 
	}
	
	//Withdraw 
	public void withdraw(double amount)
	{
		balance = balance - amount; 
	}
	
	//Get Balance 
	public double getBalance() {
		return balance; 
	}
	public static void main(String[] args) {
		Exercise7 customerone = new Exercise7();  
		customerone.deposit(100);
		

		System.out.println(customerone.getBalance());
	}

}
