import java.util.*;
 
public class Exercise5 {

	public class subscription
	{
		String email_address; 
		int months_of_subscription; 
		double dollar_amount_paid_each_month; 	
		
		public String getEmail_address() {
			return email_address;
		}
		
		public void setEmail_address(String email_address) {
			this.email_address = email_address;
		}
		public int getMonths_of_subscription() {
			return months_of_subscription;
		}
		public void setMonths_of_subscription(int months_of_subscription) {
			this.months_of_subscription = months_of_subscription;
		}
		public double getDollar_amount_paid_each_month() {
			return dollar_amount_paid_each_month;
		}
		public void setDollar_amount_paid_each_month(int dollar_amount_paid_each_month) {
			this.dollar_amount_paid_each_month = dollar_amount_paid_each_month;
		}	
	}
	
	public static double computeCustomerPay(int months_of_subscription,double dollar_amount_paid_each_month)
	{
		double total; 
		
		total = dollar_amount_paid_each_month * months_of_subscription; 
		System.out.println("Total: "+total);
		
		return (double)total; 
	}
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter your email address: ");
		String email_address = sc.nextLine();
		
		System.out.println("Months of Subscription: ");
		int months_of_subscriptoin = sc.nextInt();
		
		System.out.println("Monthly Subscription Price: ");
		double dollar_amount_paid_each_month = sc.nextDouble();
		
		computeCustomerPay(months_of_subscriptoin, dollar_amount_paid_each_month);
	}

}
