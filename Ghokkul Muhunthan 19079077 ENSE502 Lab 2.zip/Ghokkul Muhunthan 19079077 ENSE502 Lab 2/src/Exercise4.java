import java.util.Scanner;

public class Exercise4 {
	public class Person {
		static int age; 
		double weight; 
		static boolean student; 
		char gender;
		
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public double getWeight() {
			return weight;
		}
		public void setWeight(double weight) {
			this.weight = weight;
		}
		public boolean isStudent() {
			return student;
		}
		public void setStudent(boolean student) {
			this.student = student;
		}
		public char getGender() {
			return gender;
		}
		public void setGender(char gender) {
			this.gender = gender;
		} 
		
		//EXERCISE 4 EXERCISE 4 EXERCISE 4
		//returns true if this Person is a student and false otherwise  
		//Start
		public static boolean isStudent(boolean student) 
		{ 
			System.out.println("Is this person a student");
			Scanner sc = new Scanner(System.in);			
			boolean student_info  = sc.nextBoolean();
			
			if(student_info == false)
			{
				return false;	
			}else if (student_info == true)
			{
				return true; 
			}
			return student_info; 
		} 
		
		//returns the age of the Person 
		public static int getAge(int age) 
		{ 
			System.out.println("Printing age: "+age);
			return 0; 
		} 
		
		//returns 50 if this Person is a student between the age of 10 
		//and 20 (inclusive) 
		public static int computeDiscountPercent(boolean student) 
		{ 
			if(age>=10 || age>=20)
			{
				System.out.println("Age: "+age);
			}
			return 50; //returns 50 
		} 
		//Finish
		//EXERCISE 4 EXERCISE 4 EXERCISE 4

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter the person�s age:");
		int age = sc.nextInt();
		
		//Exercise 4 Now testing the ComputeDiscoutPercentage.
		computeDiscountPercent(student);
		
		//Now Testing the getAge
		getAge(age);
		
		//Testing if this Person is a student and false
		
		isStudent(student);
		
	}

	}
}
