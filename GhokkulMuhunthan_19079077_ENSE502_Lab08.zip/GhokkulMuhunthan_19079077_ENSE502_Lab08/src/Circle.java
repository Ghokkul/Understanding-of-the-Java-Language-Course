public class Circle extends Shape
{
	private double radius;
	
	public Circle()
	{
		this.radius = 1.0;
	}
	
	public Circle(double radius)
	{
		this.radius = (radius > 0? radius:1.0);
	}
	
	@Override
	// circle equation (A = pi * r^2).
	public double computeArea()
	{
		return (Math.PI * Math.pow(this.radius, 2.0));
	}
	
	@Override
	// toString method for Shape's subclass Circle.
	public String toString()
	{
		return ("Area of the circle is: " + this.computeArea() + "\n");
	}
}
