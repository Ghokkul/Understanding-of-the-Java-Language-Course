public class Dog extends Animal
{
	//Zero-parameter default constructor for Dog class.
	public Dog() 
	{
		System.out.println("Dog object instantiated");
		this.happy = 10; 
	}

	@Override
	public void feed()
	{
		this.eat +=1; 
		this.happy +=10; 
	}
	
	@Override
	//toString method.
	public String toString()
	{
		return ("Dog has " + super.toString());
	}
}
