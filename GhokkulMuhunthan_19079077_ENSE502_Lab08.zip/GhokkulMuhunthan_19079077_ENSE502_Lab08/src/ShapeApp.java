import java.util.Random;
import java.util.Scanner;

public class ShapeApp {

	public static void main(String[] args) 
	{
		// Creates a new instance of Scanner class.
		Scanner scanner = new Scanner(System.in);
				
		// Creates a String object that contains a menu.
		String menu = "1 Create a Circle Object\n";
			   menu += "2 Create a Rectangle object\n";
	           menu += "3 Stop";
	
	       	int userInput = 0;
			Shape selectedShape = null;
			
			// Do while loop to keep iterating if user selects 1 or 2.
			do
			{
				//Prints out message and it will saves the user input.
				System.out.println(menu);
				userInput = scanner.nextInt();
				
				// Switch case statement to determine based on user input.
				switch(userInput)
				{
				case 1:
					selectedShape = new Circle();
					break;
				case 2:
					selectedShape = new Rectangle();
					break;
				case 3:
					System.out.println("Goodbye!");
				}
				
				System.out.println(selectedShape);
			}
			while(userInput == 1 || userInput == 2 || userInput == 3);
		
			int userInput2 = 0;
			Random rand = new Random();
			Shape selectedShape2 = null;

			//Do while loop to keep going if user selects 1 or 2.
			do
			{
				System.out.println(menu);
				userInput2 = scanner.nextInt();
				
				// Switch case statement to determine based on user input.
				switch(userInput2)
				{
				case 1:
					selectedShape2 = new Circle(rand.nextInt(10) + 1);
					break;
				case 2:
					selectedShape2 = new Rectangle((rand.nextInt(10) + 1), (rand.nextInt(10) + 1));
					break;
				case 3: 
					System.out.println("Goodbye!");
					break;
				}
				System.out.println(selectedShape2);
					
			}
			while(userInput2 == 1 || userInput2 == 2 || userInput == 3);
	}
}

