import java.text.NumberFormat;

//Showing Mobile Service 
public abstract class SparkPlug 
{
	protected double amountOwing; //Amount Owing
	
	// Zero-parameter default constructor for SparkPlug class.
	protected SparkPlug()
	{
		this.amountOwing = 0.0;
	}
	
	protected abstract void computeBill();
	public abstract void talk(int nMinsTalked);
	public abstract void sendTexts(int nTextSent);
	
	// Getter method for SparkPlug class.
	public String getAmountOwing() 
	{
		this.computeBill();
		
		return (("Amount owing on account is: ") + NumberFormat.getCurrencyInstance().format(this.amountOwing));
	}

}
