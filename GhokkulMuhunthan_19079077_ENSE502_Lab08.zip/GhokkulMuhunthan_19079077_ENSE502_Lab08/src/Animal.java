public class Animal 
{
	protected int eat; 
	protected int happy; 
	
	//Zero parameter default constructor for Animal class.
	public Animal() 
	{
		this.eat = 0; 
		this.happy = 0; 
	}
	
	public void feed()
	{	
	}
	
	@Override
	//toString method for toString class.
	public String toString() {
		return "Eaten: " +this.eat+"Happy: "+this.happy;
	}
}
