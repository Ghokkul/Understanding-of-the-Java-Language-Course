import java.util.Random;
import java.util.Scanner;

public class SparkPlugApp 
{
	public static void main(String[] args) 
	{
		SparkPlug[] plans = new SparkPlug[3];
		plans[0] = new Standard();
		plans[1] = new DataLite();
		plans[2] = new DataHeavy();
		
		System.out.println("Please select a mobile phone package.");
		
		Scanner scanner = new Scanner(System.in);
		
		int packageSelection = -1;
		
		do
		{
			printPackageMenu(plans);
			
			packageSelection = scanner.nextInt();

			if(!(packageSelection >= 0 && packageSelection < 3))
			{
				continue;
			}
			
			useMobile(plans[packageSelection], scanner);
		}
		while(packageSelection >= 0 && packageSelection < 3);
		
		// Closes scanner.
		scanner.close();
		
		System.out.println("Thank you for using SparkPlug!");

	}
	
	public static void printPackageMenu(SparkPlug[] plans)
	{
		// For loop to iterate through the plans available.
		for(int index = 0; index < plans.length; index++)
		{
			System.out.println(index + ": " + plans[index]);
		}
		
		// Selection to stop.
		System.out.println("3: stop.");
	}
	
	public static void useMobile(SparkPlug plan, Scanner scanner)
	{	
		Random rand = new Random();
		
		String menuStandard = "1. Talk 2. Text 3. Choose another plan";
		String menuData = "1. Talk 2. Text 3. Data 4. Choose another plan";
		System.out.println(plan);
		
		int action = -1;
		
		if(plan instanceof OriginalData) 
		{
			do
			{
				System.out.println(menuData);
				action = scanner.nextInt();
				
				switch(action)
				{
				case 1:
					plan.talk(rand.nextInt(10) + 1);
					break;
				case 2:
					plan.sendTexts(rand.nextInt(30) + 1);
					break;
				case 3:
					((OriginalData) plan).transfer(rand.nextInt(500) + 1);
					break;
				}
				System.out.println(plan + plan.getAmountOwing());

			}
			while(action >= 1 && action < 4);
		}
		else if(plan instanceof Standard) 
		{
			do
			{
				System.out.println(menuStandard);
				action = scanner.nextInt();
				
				switch(action)
				{
				case 1:
					plan.talk(rand.nextInt(5) + 1);
					break;
				case 2:
					plan.sendTexts(rand.nextInt(30) + 1);
					break;
				}
				System.out.println(plan + plan.getAmountOwing());
			}
			while(action >= 1 && action < 3);
		}
	}
}
