public class Rectangle extends Shape
{
	private double length;
	private double width;
	
	// Zero-parameter default constructor for Rectangle's instance variables.
	public Rectangle()
	{
		this.length = 4.0;
		this.width = 1.0;
	}
	
	public Rectangle(double length, double width)
	{
		this.length = (length > 0? length:1.0);
		this.width = (width > 0? width:1.0);
	}
	
	@Override
	// Rectangle class using equation(A = l * w).
	public double computeArea()
	{
		return (this.length * this.width);
	}
	
	@Override
	// toString method for Shape's subclass Rectangle.
	public String toString()
	{
		return ("Area of the rectangle is: " + this.computeArea() + "\n");
	}
}