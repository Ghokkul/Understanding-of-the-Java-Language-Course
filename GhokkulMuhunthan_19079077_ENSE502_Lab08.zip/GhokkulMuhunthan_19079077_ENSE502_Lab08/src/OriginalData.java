public abstract class OriginalData extends Standard
{
	protected int nDataUsed;
	protected int dataLimit;
	
	public OriginalData()
	{
		this.nDataUsed = 0;
	}
	
	public int getnDataUsed() 
	{
		return nDataUsed;
	}

	public void transfer(int n)
	{
		if(this.nDataUsed >= this.dataLimit)
		{
			System.out.println("You have reached your data usage limits!");
		}
				
		this.nDataUsed += (n > 0? n:0);
	}

	@Override
	public String toString()
	{
		return (super.toString() + "Data: [" + this.nDataUsed + "/" + this.dataLimit + "] ");
	}
}
