public class Cat extends Animal
{
	//Zero-parameter (default) constructor for Cat class.
	public Cat() 
	{
		System.out.println("Cat object instantiated");
		this.happy = -10; 
	}
	
	@Override
	public void feed()
	{
		this.eat +=1; 
		this.happy += 10; 
	}
	
	@Override
	//toString method.
	public String toString()
	{
		return ("Cat has "+ super.toString());
	}
}
