public class DataHeavy extends OriginalData
{
	public DataHeavy()
	{
		super();
		super.minutesLimit = 30;
		super.textsLimit = 156;
		super.dataLimit = 5120;
	}
	
	@Override
	// computeBill method for DataHeavy.
	public void computeBill()
	{		
		super.amountOwing = ((super.getnMinsTalked() * 0.10) + (this.getnDataUsed() * 0.25));
	}
}
