import java.util.Scanner;

public class AnimalApplication 
{
	public static void main(String[] args) 
	{
		int externalIndex = 0;
		Scanner scanner = new Scanner(System.in);

		Animal[] animals = new Animal[4];
		
		do
		{
			selectAnimal(animals, externalIndex++, scanner);		
		}
		while(externalIndex < animals.length);
		
		managePets(animals, scanner);
		
		// Now the scanner is closed.
		scanner.close();
	}

	public static void selectAnimal(Animal[] animals, int externalIndex, Scanner scanner)
	{	
		int userInput = 0;
		
		do
		{
			// Asks user for input then saves it.
			System.out.println("Type 1 to create a Dog Object or 2 to create a Cat object");
			userInput = scanner.nextInt();
		}
		while(!(userInput == 1 || userInput == 2));
		
		switch(userInput)
		{
		case 1:
			animals[externalIndex] = new Dog();
			break;
		case 2:
			animals[externalIndex] = new Cat();
			break;
		}
	}
	
	public static void managePets(Animal[] animals, Scanner scanner)
	{
		int userInput2 = 0;
		
		do
		{
			// Asks user to select a pet to feed (0 to 3 are valid selections).
			System.out.println("Select an animal to feed by entering a number within the range: 0 to 4!");
			
			// This is a for loop to iterate through animals array. 
			for(int index = 0; index < animals.length; index++)
			{
				System.out.println(index + " " + animals[index]);
			}
			
			// Saves user's selection.
			userInput2 = scanner.nextInt();
			
			if(userInput2 >= 0 && userInput2 < 4)
			{
				animals[userInput2].feed();
			}
		}
		while (userInput2 >= 0 && userInput2 < 4);
		
		System.out.println("Input out of range, quitting.");
	}
}

