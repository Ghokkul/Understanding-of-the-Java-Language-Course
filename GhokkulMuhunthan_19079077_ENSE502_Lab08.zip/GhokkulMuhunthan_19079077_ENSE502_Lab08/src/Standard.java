public class Standard extends SparkPlug
{
	protected int nMinsTalked;
	protected int nTextSent;
	protected int minutesLimit;
	protected int textsLimit;
	
	public Standard() 
	{
		super();
		this.nMinsTalked = 0;
		this.nTextSent = 0;
		this.minutesLimit = 10;
		this.textsLimit = 100;
	}
	
	public int getnMinsTalked() 
	{
		return nMinsTalked;
	}
	public int getnTextSent() 
	{
		return nTextSent;
	}
	public int getMinutesLimit() 
	{
		return minutesLimit;
	}
	public int getTextsLimit() 
	{
		return textsLimit;
	}

	protected void computeBill()
	{
		super.amountOwing = ((this.nMinsTalked  * 0.10) + (this.nTextSent * 0.05));
	}
	
	public void talk(int nMinsTalked)
	{
		if(this.nMinsTalked >= this.getMinutesLimit())
		{
			System.out.println("You have reached your minutes limit!");
		}
	
		this.nMinsTalked += (nMinsTalked > 0? nMinsTalked:0);
	}
	
	public void sendTexts(int nTextSent)
	{
		if(this.nTextSent >= this.getTextsLimit())
		{
			System.out.println("You have reached your texts limit!");
		}
		
		this.nTextSent += (nTextSent > 0? nTextSent:0);
	}
	
	@Override
	// toString method for Standard class.
	public String toString()
	{
		return ("Talk: [" + this.getnMinsTalked() + "/" + this.getMinutesLimit() 
				+ "] Text: [" + this.getnTextSent() + "/" + this.getTextsLimit() + "] ");
	}
}
