//Abstract Class Shape.
public abstract class Shape 
{
	public abstract double computeArea();
}