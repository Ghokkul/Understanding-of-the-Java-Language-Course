public class DataLite extends OriginalData
{
	public DataLite()
	{
		super();
		super.minutesLimit = 20;
		super.textsLimit = 56;
		super.dataLimit = 1024;
	}
	
	
	@Override
	// computeBill method for DataLite.
	public void computeBill()
	{
		super.computeBill();
		
		super.amountOwing += (this.getnDataUsed() * 0.15);
	}
}
